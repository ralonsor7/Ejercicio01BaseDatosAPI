package com.cev.prueba.prueba.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cev.prueba.prueba.domain.Pelicula;
import com.cev.prueba.prueba.repository.PeliculaRepository;

@Service
public class PeliculaPersistService {
	
	PeliculaRepository pelicularepository;
	
	public PeliculaPersistService(PeliculaRepository pelicularepository) {
		this.pelicularepository = pelicularepository;
	}
	
	public Pelicula getPelicula(Long id) {
		return pelicularepository.getOne(id);
	}
	
	public Long add(Pelicula pelicula) {
		Pelicula peliculaGuardada = pelicularepository.save(pelicula);
		return peliculaGuardada.getId();
	}
	
	public List <Pelicula> getPeliculas() {
		return pelicularepository.findAll();
	}
	
	public void guardada(Long id, Pelicula pelicula) {
		Pelicula peliculaGuardada = pelicularepository.getOne(id);
		peliculaGuardada.setDirector(pelicula.getDirector());
		peliculaGuardada.setFechaEstreno(pelicula.getFechaEstreno());
		peliculaGuardada.setPuntuacion(pelicula.getPuntuacion());
		peliculaGuardada.setSinopsis(pelicula.getSinopsis());
		peliculaGuardada.setTitulo(pelicula.getTitulo());
		pelicularepository.save(peliculaGuardada);
	}
	
	public void borra(Long id) {
		pelicularepository.delete(pelicularepository.getOne(id));
	}
	
	public Optional<Pelicula> findById(Long id) {
		return pelicularepository.findById(id);
	}

	public List<Pelicula> buscaPorTitulo(String titulo) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public List<Pelicula> findByTituloContaining(String Titulo) {
		return pelicularepository.findByTituloContaining(Titulo);
	}

}
