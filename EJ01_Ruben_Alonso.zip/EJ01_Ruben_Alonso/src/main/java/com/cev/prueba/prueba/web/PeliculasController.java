package com.cev.prueba.prueba.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cev.prueba.prueba.domain.Pelicula;
import com.cev.prueba.prueba.repository.PeliculaRepository;
import com.cev.prueba.prueba.service.PeliculaPersistService;
import com.cev.prueba.prueba.web.error.CustomError;

@RestController
 class PeliculasController {
	
	@Autowired 
	PeliculaPersistService peliculaPersistService;			
	
	@Autowired 
	PeliculaRepository peliculaRepository;			
	
	@GetMapping(path = "/peliculas")
	List<Pelicula> getPeliculas(@RequestParam(required = false) String titulo,
			@RequestParam(required = false, name = "puntuacion.min") Integer puntuacionMin,
			@RequestParam(required = false, name = "puntuacion.max") Integer puntuacionMax,
			@RequestParam(required = false, name = "cine") String cine){
		
		
			if (cine!= null) {
				peliculaRepository.findByCine_nombreOrderByPuntuacionDesc(cine);
			}
			
			
		
		if(puntuacionMin!= null) {
			if(puntuacionMax!= null) { 
				if(titulo!= null){ //PuntuacionMin, PuntuacinoMax, titulo
					return peliculaRepository.findByTituloContainingIgnoreCaseAndPuntuacionGreaterThanEqualAndPuntuacionLessThanEqual(titulo, puntuacionMin, puntuacionMax);
				}else { //PuntuacionMin, PuntuacinoMax, titulo=NULL
					return peliculaRepository.findByTituloPuntuacionGreaterThanEqualAndPuntuacionLessThanEqual(puntuacionMin, puntuacionMax);
				}
			}else{
				if(titulo!= null){ //PuntuacionMin = NULL, PuntuacinoMax = NULL, titulo
					return peliculaRepository.findByTituloContainingIgnoreCaseAndPuntuacionGreaterThanEqual(titulo, puntuacionMin);
				}else { //PuntuacionMin = NULL, PuntuacinoMax = NULL, titulo=NULL
					return peliculaRepository.findByTituloPuntuacionGreaterThanEqual(puntuacionMin);
				}
			}
		}else{
			if(puntuacionMax!= null) {
				if(titulo!= null){ //PuntuacionMin = NULL, PuntuacinoMax, titulo
					return peliculaRepository.findByTituloContainingIgnoreCaseAndPuntuacionLessThanEqual(titulo, puntuacionMax);
				}else{//PuntuacionMin, PuntuacinoMax, titulo=NULL
					return peliculaRepository.findByPuntuacionThanEqual(puntuacionMax);
				}
			}else{
				if(titulo!= null){ //PuntuacionMin = NULL, PuntuacinoMax = NULL, titulo
					return peliculaRepository.findByTituloContainingIgnoreCase(titulo);
				}else { //PuntuacionMin = NULL, PuntuacinoMax = NULL, titulo=NULL
					return peliculaRepository.findAll();
				}
			}
		}
	}



	//return peliculaPersistService.getPeliculas();
	
	
	@GetMapping(path = "/peliculas/{id}")
	Pelicula getPeliculas(@PathVariable Long id){	
		if (peliculaPersistService.findById(id).isPresent()) {
			return peliculaPersistService.findById(id).get();
		} else {
			throw new CustomError ("No encuentroesa película");
		}
		//return peliculaPersistService.getPelicula(id);		
	}
	
	@PostMapping(path = "/peliculas")
	Long altaPelicula(@RequestBody Pelicula pelicula ) {				
		return peliculaPersistService.add(pelicula);		
	}
	
	@PutMapping(path = "/peliculas/{id}")
	Pelicula modificaPelicula(@RequestBody Pelicula pelicula,@PathVariable Long id) {
		peliculaPersistService.guardada(id, pelicula);			
		return pelicula;		
	}
	
	@DeleteMapping(path="/peliculas/{id}")
	String borraPelicula(@PathVariable Long id) {	
		peliculaPersistService.borra(id);	
		return("OK");
	}
	
	@GetMapping(path = "/peliculasHeader")
	ResponseEntity<List<Pelicula>> getPeliculasHeader(){		
		HttpHeaders headers = new HttpHeaders();
		headers.add("MiHeaderRespuesta", "HeaderRespuesta");
		
		return ResponseEntity.ok().headers(headers).body(peliculaPersistService.getPeliculas());
	}
		
}
