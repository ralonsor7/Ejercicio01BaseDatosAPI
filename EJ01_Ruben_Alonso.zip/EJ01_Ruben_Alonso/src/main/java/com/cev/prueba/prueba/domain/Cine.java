package com.cev.prueba.prueba.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Cine {

	
	@Id
	@GeneratedValue
	Long id;
	
	String nombreCine;
	String poblacion;
	int codigoPostal;
	String Provincia;
	int precioEntrada;
	
	
	@ManyToOne
	@JsonBackReference
	Pelicula pelicula;


	// GETTER & SETTER
	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getNombreCine() {
		return nombreCine;
	}


	public void setNombreCine(String nombreCine) {
		this.nombreCine = nombreCine;
	}


	public String getPoblacion() {
		return poblacion;
	}


	public void setPoblacion(String poblacion) {
		this.poblacion = poblacion;
	}


	public int getCodigoPostal() {
		return codigoPostal;
	}


	public void setCodigoPostal(int codigoPostal) {
		this.codigoPostal = codigoPostal;
	}


	public String getProvincia() {
		return Provincia;
	}


	public void setProvincia(String provincia) {
		Provincia = provincia;
	}


	public int getPrecioEntrada() {
		return precioEntrada;
	}


	public void setPrecioEntrada(int precioEntrada) {
		this.precioEntrada = precioEntrada;
	}


	public Pelicula getPelicula() {
		return pelicula;
	}


	public void setPelicula(Pelicula pelicula) {
		this.pelicula = pelicula;
	}
	
}


