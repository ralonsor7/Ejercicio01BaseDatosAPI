package com.cev.prueba.prueba.repository;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cev.prueba.prueba.domain.Cine;

@Repository
public interface CineRepository extends JpaRepository<Cine, Long>{

	//List<Cine> findAll();

}
