package com.cev.prueba.prueba.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cev.prueba.prueba.domain.Pelicula;

@Repository
public interface PeliculaRepository extends JpaRepository<Pelicula, Long> {
	Pelicula getOne(Long id);

	List<Pelicula> findByTituloContaining(String titulo);

	List<Pelicula> findByTituloContainingIgnoreCaseAndPuntuacionGreaterThanEqualAndPuntuacionLessThanEqual(String titulo,
			Integer puntuacionMin, Integer puntuacionMax);

	List<Pelicula> findByTituloPuntuacionGreaterThanEqualAndPuntuacionLessThanEqual(Integer puntuacionMin,
			Integer puntuacionMax);

	List<Pelicula> findByTituloContainingIgnoreCaseAndPuntuacionGreaterThanEqual(String titulo, Integer puntuacionMin);

	List<Pelicula> findByTituloPuntuacionGreaterThanEqual(Integer puntuacionMin);

	List<Pelicula> findByPuntuacionThanEqual(Integer puntuacionMax);

	List<Pelicula> findByTituloContainingIgnoreCaseAndPuntuacionLessThanEqual(String titulo, Integer puntuacionMax);

	List<Pelicula> findByTituloContainingIgnoreCase(String titulo);
	
	List<Pelicula> findByCine_nombreOrderByPuntuacionDesc(String nombre);
	
	@Query("Select pelicula from Pelicula pelicula where pelicula.titulo =:titulo")
	List<Pelicula> findByTituloHibernate(@Param("titulo") String titulo);
}
